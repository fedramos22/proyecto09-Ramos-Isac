//ACTIVIDAD 2

let verGatos = 5;
let verPasos = 3;
let gatoBlanco = "🐈";
let pasos = "🐾";

for (let index = 0; index < verGatos; index++) {

    console.log(gatoBlanco + pasos.repeat(verPasos) );
}